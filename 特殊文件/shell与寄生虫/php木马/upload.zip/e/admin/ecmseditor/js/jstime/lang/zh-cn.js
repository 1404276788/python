var $lang={
errAlertMsg: "不合法的日期格式或者日期超出限定范围,需要撤销吗?",
aWeekStr: ["周","日","一","二","三","四","五","六"],
aMonStr: ["一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一","十二"],
clearStr: "清空",
todayStr: "今天",
okStr: "确定",
updateStr: "更新",
timeStr: "时间",
quickStr: "快速选择", 
err_1: '最小日期不能大于最大日期!'
}